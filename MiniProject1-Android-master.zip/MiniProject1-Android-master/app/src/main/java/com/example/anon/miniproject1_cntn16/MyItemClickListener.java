package com.example.anon.miniproject1_cntn16;

import android.view.View;

public interface MyItemClickListener {
    void onClick(View view);
}

