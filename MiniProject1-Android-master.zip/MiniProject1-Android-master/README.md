# MiniProject1-Android

Change Google API key in secrets.xml