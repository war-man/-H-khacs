## Lab 01 - 01
### Requirements
- Adding a click listener to a Button
- Adding a text changed listener to a EditText
- Using getText and setText method with EditText
- Displaying Toast
- Disable/Enable View (Button, EditText, TextView,…)

## Lab 01 - 02
### Requirements
- Working with CheckBox
- Working with RadioGroup