## Lab 7 - 01
### Requirements:
- Working with Shared Preferences

## Lab 7 - 02
### Requirements:
- Writing internal/external file
- Reading internal/external file

### Output:
<img width="400" src="https://github.com/cminhho/TDTU-LapTrinhUngDungDiDong/blob/master/Lab07/screenshots/device-2019-03-23-lab07-02.png" alt="Writing internal/external file, Reading internal/external file"/>

## Lab 7 - 03
### Requirements:
-  Creating a simple Contact App with SQLite as database storage

### Output:
<img width="400" src="https://github.com/cminhho/TDTU-LapTrinhUngDungDiDong/blob/master/Lab07/screenshots/device-2019-03-23-lab07-03.png" alt="Creating a simple Contact App with SQLite as database storage"/>

<img width="400" src="https://github.com/cminhho/TDTU-LapTrinhUngDungDiDong/blob/master/Lab07/screenshots/device-2019-03-23-lab07-03-edit.png"/>
