## Lab 04 - 01
### Requirements
- Working with Simple Android ListView
- Showing selected row data in Toast as on ListView Row Click

## Lab 04 - 02
### Requirements
- Remvoing selected row data on ListView Row
### Output
<img width="400" src="https://github.com/cminhho/TDTU-LapTrinhUngDungDiDong/blob/master/Lab04/screenshots/device-2019-03-23-lab04-02.png" alt="Remvoing selected row data on ListView Row"/>

## Lab 04 - 03
### Requirements
- Working with TableLayout
### Output
<img width="400" src="https://github.com/cminhho/TDTU-LapTrinhUngDungDiDong/blob/master/Lab04/screenshots/device-2019-03-23-lab04-03.png" alt="Working with TableLayout"/>
