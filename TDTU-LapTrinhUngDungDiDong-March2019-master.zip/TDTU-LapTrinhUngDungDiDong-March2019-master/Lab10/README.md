## Lab Exercises  

### Lab 10 - 01
<b>Requirements:</b>
- Create a List with RecyclerView

<b>Output:</b>

<img width="400" src="https://github.com/cminhho/TDTU-LapTrinhUngDungDiDong/blob/master/Lab10/screenshots/exercise1.png" alt="Create a List with RecyclerView"/>


### Lab 10 - 02
<b>Requirements:</b>
- Working with GPS Location on Android

<b>Output:</b>

<img width="400" src="https://github.com/cminhho/TDTU-LapTrinhUngDungDiDong/blob/master/Lab10/screenshots/exercise2.png" alt="Working with Service + AsynTask"/>

### Lab 10 - 03
<b>Requirements:</b>
