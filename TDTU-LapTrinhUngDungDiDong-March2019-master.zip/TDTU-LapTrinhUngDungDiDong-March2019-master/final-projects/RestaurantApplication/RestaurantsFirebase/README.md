# Firebase Restaurant App
### Introduction

## Setup

Follow the <a href="https://codelabs.developers.google.com/codelabs/firestore-android/index.html">Cloud Firestore Android Codelab</a> to set up this project.

### Output

#### Android: 
<img src="./sceenshots/home.png" height="534" width="300"/>

