## Lab 02 - 01
### Requirements
- Working with LinearLayout and RelativeLayout
### Output:
<img width="400" src="https://github.com/cminhho/TDTU-LapTrinhUngDungDiDong/blob/master/Lab02/screenshots/device-2019-03-23-lab02-01.png" alt="Working with LinearLayout and RelativeLayout"/>


## Lab 02 - 02
### Requirements
- Design Android Calculator application layout
### Output:
<img width="400" src="https://github.com/cminhho/TDTU-LapTrinhUngDungDiDong/blob/master/Lab02/screenshots/device-2019-03-23-lab02-02.png" alt="Design Android Calculator application layout"/>


## Lab 02 - 03
### Requirements
- Working with ImageView and assets resource 
### Output:
<img width="400" src="https://github.com/cminhho/TDTU-LapTrinhUngDungDiDong/blob/master/Lab02/screenshots/device-2019-03-23-lab02-03.png" alt="Working with ImageView and assets resource "/>


 
