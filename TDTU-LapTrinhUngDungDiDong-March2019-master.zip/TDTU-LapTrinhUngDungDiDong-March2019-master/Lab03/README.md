## Lab 03 - 01
### Requirements
- Starting other Android components via intents 
- Data transfer between activities 
- Registering for intents via intent filters 
- Activity communication with intents 

## Lab 03 - 02
### Requirements
- Opening a URL in Android's web browser from the application

## Lab 03 - 03
### Requirements
- Create Web Browser Android Application

## Lab 03 - 04
### Requirements
- Working with Activity's lifecycle
 