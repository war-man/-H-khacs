## Lab 06 - 01
### Requirements
- Working with Android - Alert Dialog
- Working with Single Choice Alert Dialog
- Working with Multiple Choice Alert Dialog

## Lab 06 - 02
### Requirements
- Attaching a Context Menu to a ListView

## Lab 06 - 03
### Requirements
- Attaching a Context Menu to application
