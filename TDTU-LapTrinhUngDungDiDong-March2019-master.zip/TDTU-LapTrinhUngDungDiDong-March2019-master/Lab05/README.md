## Lab 05 - 01
### Requirements
- Working with Custom ListView items and adapters
### Output
<img width="400" src="https://github.com/cminhho/TDTU-LapTrinhUngDungDiDong/blob/master/Lab05/screenshots/device-2019-03-23-lab05-01.png" alt="Working with Custom ListView items and adapters"/>

## Lab 05 - 02
### Requirements
- Adding items to a Custom ListView
### Output
<img width="400" src="https://github.com/cminhho/TDTU-LapTrinhUngDungDiDong/blob/master/Lab05/screenshots/device-2019-03-23-lab05-02.png" alt="Adding items to a Custom ListView"/>


## Lab 05 - 03
### Requirements
- Working with GridView
### Output
<img width="400" src="https://github.com/cminhho/TDTU-LapTrinhUngDungDiDong/blob/master/Lab05/screenshots/device-2019-03-23-lab05-03.png" alt="Working with GridView"/>
