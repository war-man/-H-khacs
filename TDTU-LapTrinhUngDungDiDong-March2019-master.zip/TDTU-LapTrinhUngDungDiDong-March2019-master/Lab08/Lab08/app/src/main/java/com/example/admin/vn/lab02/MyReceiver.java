package com.example.admin.vn.lab02;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.support.v4.app.NotificationCompat;
import android.util.Log;
import android.widget.Toast;

/**
 * Created by thChung on 3/30/2019.
 */

public class MyReceiver extends BroadcastReceiver {

    private static final String TAG = MyReceiver.class.getName();

    @Override
    public void onReceive(Context context, Intent intent) {
    }

}