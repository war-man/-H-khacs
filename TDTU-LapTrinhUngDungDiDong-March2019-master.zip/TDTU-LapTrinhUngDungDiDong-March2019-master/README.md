# TDTU-LapTrinhUngDungDiDong
## Introduction
Providing Android exercises for reference purposes.

## Lab exercise

## Final exercise
<b>Restaurant project</b>
- Live demo: https://tdt-firestore-d67b0.firebaseapp.com/

## References
- https://developer.android.com/studio/workflow

