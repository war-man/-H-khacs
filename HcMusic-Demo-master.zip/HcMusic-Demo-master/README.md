# HcMusic-Demo
基于Android平台的一款简单音乐播放器

![Image text](https://raw.githubusercontent.com/QiuQiuqiubao/HcMusic-Demo/master/img/1.png)
--------------------------------------------------------------------------------------------------------------------------
![Image text](https://raw.githubusercontent.com/QiuQiuqiubao/HcMusic-Demo/master/img/2.png)
--------------------------------------------------------------------------------------------------------------------------
