package com.example.asus.qqapp.playMusic;

import com.example.asus.qqapp.bean.MusicBean;

import java.util.List;

/**
 * Created by asus on 2018/1/18.
 */

public interface ILocalMusicView {
    void initLv(List<MusicBean> list);
}
