package com.example.asus.qqapp;

import android.support.v4.app.Fragment;

/**
 * Created by asus on 2018/1/18.
 */

public class BaseFragment extends Fragment{
}
