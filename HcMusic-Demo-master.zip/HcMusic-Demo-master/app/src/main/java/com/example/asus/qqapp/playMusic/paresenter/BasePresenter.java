package com.example.asus.qqapp.playMusic.paresenter;

/**
 * Created by asus on 2018/1/19.
 */

public interface BasePresenter {
    void start();
}
