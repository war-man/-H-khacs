# HCMUSHandbook
Provide public website API and database structure for news. And Android application to view those news
