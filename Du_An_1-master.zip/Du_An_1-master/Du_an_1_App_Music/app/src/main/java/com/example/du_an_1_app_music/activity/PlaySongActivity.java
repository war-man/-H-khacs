package com.example.du_an_1_app_music.activity;


import com.example.du_an_1_app_music.R;
import com.example.du_an_1_app_music.base.BaseActivity;
import com.example.du_an_1_app_music.databinding.ActivityPlaySongBinding;

public class PlaySongActivity extends BaseActivity<ActivityPlaySongBinding> {
    @Override
    protected void intAct() {

    }

    @Override
    protected int getLayoutId() {
        return R.layout.activity_play_song;
    }
}
