package com.example.mrrs.schoolhelper.model;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class Login {

    @SerializedName("acc_id")
    @Expose
    private String acc_id;
    @SerializedName("user_name")
    @Expose
    private String user_name;

    @SerializedName("password")
    @Expose


    private String password;

    public String getIdsv() {
        return acc_id;
    }

    public void setIdsv(String idsv) {
        this.acc_id = idsv;
    }

    public String getUser() {
        return user_name;
    }

    public void setUser(String user) {
        this.user_name = user;
    }

    public String getPass() {
        return password;
    }

    public void setPass(String pass) {
        this.password = pass;
    }

}