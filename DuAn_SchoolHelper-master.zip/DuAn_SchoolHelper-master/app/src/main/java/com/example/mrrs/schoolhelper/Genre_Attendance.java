package com.example.mrrs.schoolhelper;

import com.thoughtbot.expandablerecyclerview.models.ExpandableGroup;

import java.util.List;

public class Genre_Attendance extends ExpandableGroup {
    public Genre_Attendance( String title, List items) {
        super( title, items);
    }
}
