package com.example.mrrs.schoolhelper.model;

public class AttendanceModel {
    private String name;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public AttendanceModel(String name) {

        this.name = name;
    }
}
