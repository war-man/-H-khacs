package com.example.mrrs.schoolhelper.service;
import com.example.mrrs.schoolhelper.model.Attendance;
import com.example.mrrs.schoolhelper.model.LocationMap;
import com.example.mrrs.schoolhelper.model.Login;
import com.example.mrrs.schoolhelper.model.Student;
import java.util.List;

import javax.xml.transform.Result;

import retrofit2.Call;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.GET;
import retrofit2.http.POST;

public interface Dataservice {
    @GET("student.php")
    Call<List<Student>> GetDataInfoStudent();
    @GET("location.php")
    Call<List<LocationMap>> GetDataLocation();
    @GET("attendance.php")
    Call<List<Attendance>> GetDataAttendance();


    @FormUrlEncoded
    @POST("login.php")
    Call<List<Login>> Login(@Field("user_name") String user, @Field("password") String pass);

    @FormUrlEncoded
    @POST("student.php")
    Call<List<Student>> Student(@Field("acc_id") String acc_id);
}
