package com.example.mrrs.schoolhelper.model;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class LocationMap {

    @SerializedName("lat")
    @Expose
    private String latmap;
    @SerializedName("lng")
    @Expose
    private String longmap;
    @SerializedName("type")
    @Expose
    private String stay;

    public LocationMap(String latmap, String longmap, String stay) {
        this.latmap = latmap;
        this.longmap = longmap;
        this.stay = stay;
    }

    public String getLatmap() {
        return latmap;
    }

    public void setLatmap(String latmap) {
        this.latmap = latmap;
    }

    public String getLongmap() {
        return longmap;
    }

    public void setLongmap(String longmap) {
        this.longmap = longmap;
    }

    public String getStay() {
        return stay;
    }

    public void setStay(String stay) {
        this.stay = stay;
    }

}