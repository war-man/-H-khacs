package com.example.mrrs.schoolhelper.service;

public class APIConnect {
//    public static final String IP = "10.200.201.137";

    public static final String HOST_URL = "http://ndttamdev.tech/APIs/";
    public static final String URL_LOGIN = HOST_URL + "login.php";
    public static final String URL_FEEDBACK = HOST_URL + "feedback.php";
    public static final String URL_FORGOT = HOST_URL + "resetpassword.php";
    public static final String URL_LOCATION = HOST_URL+"location.php";
//    public static final String URL_INFO = HOST_URL+"student.php";

}
