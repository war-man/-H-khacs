package com.team3jp.MoneyMan.Items;

public class ObjectPieChart {

    double Thu;
    double Chi;

    public ObjectPieChart(double thu, double chi) {
        this.Thu = thu;
        this.Chi = chi;
    }

    public double getThu() {
        return Thu;
    }

    public double getChi() {
        return Chi;
    }

    public void setThu(double thu) {
        this.Thu = thu;
    }

    public void setChi(double chi) {
        this.Chi = chi;
    }
}
