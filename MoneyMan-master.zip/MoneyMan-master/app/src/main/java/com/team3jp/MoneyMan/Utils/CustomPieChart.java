package com.team3jp.MoneyMan.Utils;

import android.support.v4.app.Fragment;

public class CustomPieChart extends Fragment {
    int type;//Biến vào loại liệt kê theo tuần theo tháng theo năm
    int data; //lấy dữ liệu từ database tương ứg
    //Vẽ
    //Trả ra fragment
}
